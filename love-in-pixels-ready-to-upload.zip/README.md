# love-in-pixels

A browser build of **The Heart in ASCII**.

The original animation logic is retained from the supplied Python source. The main loop is adapted for Pygbag's browser event loop.

## Build

```bash
python -m pip install pygbag
python -m pygbag --build main.py
```

The static website files are generated in `build/web/`.

Original source credit: `@dwcminh.ascii` (kept in the source header).
